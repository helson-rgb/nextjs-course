---
name: Technical Warmth
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#ffb2b7'
  on-tertiary: '#67001b'
  tertiary-container: '#ff516a'
  on-tertiary-container: '#5b0017'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is built on the philosophy of "Technical Warmth." It bridges the gap between the high-precision, austere aesthetic of developer tools and the inviting, human-centric nature of education. The visual language is deeply inspired by modern software engineering culture—drawing from the likes of Vercel and Linear—but introduces soft geometric shapes and a vibrant accent palette to signal accessibility.

The style is **Modern Corporate with a Minimalist lean**, utilizing heavy whitespace and crisp borders to ensure clarity, while employing "Glassmorphism" and subtle "Tonal Layers" to prevent the interface from feeling cold or intimidating. The goal is to evoke a sense of focused competence and welcoming mentorship.

## Colors
The palette is centered around **Electric Indigo**, a vibrant evolution of the traditional React blue, serving as the primary brand anchor. 

- **Primary (Electric Indigo):** Used for primary actions, progress indicators, and active states.
- **Secondary (Amber):** Provides "Technical Warmth." Used sparingly for highlights, course certifications, and motivational callouts.
- **Tertiary (Coral):** An optional secondary accent for high-energy interactions or marketing sections.
- **Neutrals:** A sophisticated 9-step scale. In **Dark Mode**, we utilize "Inky Slates" (#0F172A) to provide more depth than pure black. In **Light Mode**, we shift to "Cool Grays" to maintain a crisp, airy feel.

Surface backgrounds should utilize the neutral scale, while interactive elements leverage the primary indigo for clear visual hierarchy.

## Typography
The typography strategy creates a distinct "Engineering Editorial" feel. 

1. **Display & Headlines:** Use **Plus Jakarta Sans**. Its soft, geometric curves provide the "warmth" in the system, making large headers feel approachable.
2. **Body Text:** Use **Inter**. It is the industry standard for UI legibility, ensuring that complex technical documentation is easy to digest over long periods.
3. **Technical Labels:** Use **Geist Sans**. This font is reserved for UI labels, code snippets, metadata, and "developer-only" information. Its technical, monospaced-leaning rhythm reinforces the platform's authority in the React ecosystem.

For mobile, scale down display sizes significantly while maintaining generous line heights for body copy to prevent visual fatigue.

## Layout & Spacing
The layout follows a **Fluid Grid** system based on a 4px baseline unit. 

- **Desktop:** 12-column grid with 24px gutters. Content is primarily centered with a max-width of 1280px for standard pages and 1440px for the dashboard/IDE views.
- **Mobile:** 4-column grid with 16px margins. 
- **Rhythm:** Use "md" (24px) for most component spacing and "lg" (48px) for section vertical spacing to create a sense of air and premium quality. 

Sidebars (for course navigation) should be fixed-width (280px) on desktop to provide a stable anchor for the fluid content area.

## Elevation & Depth
Hierarchy is established through **Tonal Layers** combined with **Ambient Shadows**. 

- **Level 0 (Background):** The lowest layer. In dark mode, this is the deepest slate.
- **Level 1 (Cards/Containers):** Raised slightly using a subtle background color shift (1-step lighter/darker) and a 1px low-contrast outline.
- **Level 2 (Popovers/Modals):** These use high-diffusion ambient shadows (0px 20px 50px rgba(0,0,0, 0.3)) and a subtle backdrop blur (12px) to simulate a glass effect, keeping the developer focused on the task at hand.

Avoid heavy black shadows; instead, use shadows tinted with the primary Indigo or deep Slate to maintain color harmony.

## Shapes
The shape language is **Rounded**, utilizing a 0.5rem (8px) base radius. This strikes the perfect balance between the sharp 0px/4px corners found in strict developer tools and the overly bubbly 16px+ corners of consumer apps.

- **Standard Elements (Buttons, Inputs):** 8px radius.
- **Large Elements (Cards, Course Thumbnails):** 16px (rounded-lg) to 24px (rounded-xl) radius.
- **Iconography:** Icons must follow a 4px corner radius for internal shapes and a 1.5px stroke weight to feel precise yet friendly.

## Components
- **Buttons:** Primary buttons use a solid Electric Indigo fill with white text. Secondary buttons use a subtle ghost style with a 1px border. Interactions should be snappy—use a 150ms transition for hover states.
- **Inputs:** Form fields feature a subtle inset shadow and a 1px border. On focus, the border transitions to Electric Indigo with a soft outer glow.
- **Cards:** Cards for course modules should be minimalist, using typography and small chips to convey info rather than heavy imagery.
- **Chips/Badges:** Use these for "New," "Advanced," or "Beta" tags. They should use a light tint of the primary or secondary color (10% opacity) with high-contrast text.
- **Code Blocks:** A signature component. Use a custom "Inky" background, syntax highlighting that matches the brand palette, and a "Copy" button that appears on hover in the top-right.
- **Progress Bars:** Use a thick (8px) bar with a gradient from Electric Indigo to Coral to visualize course completion, adding a playful sense of momentum.